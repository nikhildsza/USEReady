import streamlit as st
import requests

st.title("Contract Metadata Extractor")

uploaded_file = st.file_uploader("Upload a DOCX or PDF file", type=["docx", "pdf" , "png"])

if uploaded_file:
    with st.spinner("Extracting metadata..."):
        response = requests.post("http://localhost:8000/extract", files={"file": uploaded_file})
        if response.status_code == 200:
            metadata = response.json()
            if "error" in metadata:
                st.error("Failed to extract metadata.")
                st.write("Raw Output:", metadata.get("raw_output"))
            else:
                st.success("Metadata extracted successfully!")
                st.json(metadata)
        else:
            st.error("Failed to extract metadata.")

if st.button("Evaluate on Test Set"):
    response = requests.get("http://localhost:8000/evaluate")
    if response.status_code == 200:
        st.write(response.json())
    else:
        st.error("Evaluation failed")