from fastapi import FastAPI, UploadFile, File
from extract_text import extract_text_from_file
from metadata_predictor import get_metadata
from evaluator import evaluate_predictions
import json

app = FastAPI()

@app.post("/extract")
async def extract(file: UploadFile = File(...)):
    text = extract_text_from_file(await file.read(), file.filename)
    metadata = get_metadata(text)
    return metadata

@app.get("/evaluate")
def evaluate():
    return evaluate_predictions()