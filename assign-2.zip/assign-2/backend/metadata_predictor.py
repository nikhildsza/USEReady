import os
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.output_parsers import JsonOutputParser
from langchain.schema.messages import SystemMessage, HumanMessage
from dotenv import load_dotenv

load_dotenv()

llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash-lite", google_api_key=os.getenv("GOOGLE_API_KEY"))

prompt_template = """
Extract the following metadata fields from the agreement text below.
Return only a dictionary with these keys and their respective values:
- agreement_value
- start_date
- end_date
- renewal_notice
- party_one
- party_two


Now extract from this agreement text:

{text}
"""

parser = JsonOutputParser()

def get_metadata(text):
    prompt = [
        SystemMessage(content="You are an expert contract metadata extractor."),
        HumanMessage(content=prompt_template.replace("{text}", text))
    ]

    try:
        output = llm.invoke(prompt)
        raw = output.content
        if raw.startswith("```json"):
            raw = raw.replace("```json", "").strip()
        if raw.endswith("```"):
            raw = raw[:-3].strip()
        
    except Exception as e:
        print("JSON Parse Error:", e)
        return {"error": "LLM did not return valid JSON", "raw_output": output.content if output else None}

    return raw
