import pandas as pd
import json

def evaluate_predictions():
    ground_truth = pd.read_csv("../data/test.csv")
    predictions = json.load(open("../predictions/predictions.json"))
    pred_df = pd.DataFrame(predictions)
    merged = pd.merge(ground_truth, pred_df, on="filename", suffixes=("_true", "_pred"))
    fields = ["agreement_value", "start_date", "end_date", "renewal_notice", "party_one", "party_two"]
    recall = {}
    for field in fields:
        correct = (merged[f"{field}_true"].astype(str).str.strip().str.lower() ==
                   merged[f"{field}_pred"].astype(str).str.strip().str.lower()).sum()
        recall[field] = correct / len(merged)
    return recall
